// priority: 0

console.info('cargando items kubejs...')


StartupEvents.registry('item', event => {
  event.create('plushie_bag')
    .displayName('Bolsa Misteriosa')
    .texture('kubejs:item/conlentes') // 
})


StartupEvents.registry('item', event => {
  event.create('tussi')
    .displayName('Tussi')
    .texture('minecraft:item/bolsitadetussi')
})