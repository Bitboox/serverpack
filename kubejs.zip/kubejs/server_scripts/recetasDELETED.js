ServerEvents.recipes(event => {

  //  Elimina una receta por ID
event.remove({ id: 'jeg:pistol_ammo' });
event.remove({ id: 'jeg:rifle_ammo' });
event.remove({ id: 'jeg:ammo_box' });
event.remove({ id: 'jeg:handmade_shell' });
event.remove({ id: 'jeg:shotgun_shell' });
event.remove({ id: 'jeg:spectre_round' });
event.remove({ id: 'jeg:rocket' });
event.remove({ id: 'jeg:grenade' });
event.remove({ id: 'jeg:' });

  //  Elimina TODAS las recetas de un item (recomendado)
event.remove({ output: 'jeg:pistol_ammo' });
event.remove({ output: 'jeg:rifle_ammo' });
event.remove({ output: 'jeg:ammo_box' });
event.remove({ output: 'jeg:handmade_shell' });
event.remove({ output: 'jeg:shotgun_shell' });
event.remove({ output: 'jeg:rocket' });
event.remove({ output: 'jeg:grenade' });
event.remove({ output: 'jeg:' });

// eliminar todas las recetas del MOD
event.remove({ mod: 'nenus_pop_plushies' })

});