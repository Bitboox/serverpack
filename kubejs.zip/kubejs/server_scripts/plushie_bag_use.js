// priority: 0
console.info('cargando uso de bolsa...')

const plushies = [
  'nenus_pop_plushies:bingo_plushie',
  'nenus_pop_plushies:foo_fighters_plushie',
  'nenus_pop_plushies:teemo_plushie'
];

ItemEvents.rightClicked('kubejs:plushie_bag', event => {
  let player = event.player;

  // Elegir peluche random
  let random = plushies[Math.floor(Math.random() * plushies.length)];

  player.playSound('minecraft:entity.player.levelup', 1, 1);

  // Dar el ítem
  player.give(random);

  // Consumir la bolsa
  event.item.count--;
});

